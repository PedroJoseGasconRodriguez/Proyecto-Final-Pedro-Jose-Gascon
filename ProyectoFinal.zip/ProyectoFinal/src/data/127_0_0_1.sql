-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 15-12-2024 a las 15:17:19
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `proyecto`
--
CREATE DATABASE IF NOT EXISTS `proyecto` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `proyecto`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cuentas`
--

CREATE TABLE `cuentas` (
  `nombre` varchar(15) NOT NULL,
  `contraseña` varchar(15) NOT NULL,
  `pregunta` varchar(30) NOT NULL,
  `respuesta` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `cuentas`
--

INSERT INTO `cuentas` (`nombre`, `contraseña`, `pregunta`, `respuesta`) VALUES
('admin', 'adm0nl0c4l', '¿Nombre de tu primera mascota?', 'azulito');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `multimedia`
--

CREATE TABLE `multimedia` (
  `titulo` varchar(50) NOT NULL,
  `descripcion` varchar(100) NOT NULL,
  `genero` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `multimedia`
--

INSERT INTO `multimedia` (`titulo`, `descripcion`, `genero`) VALUES
('Alien vs predator', '\0Pelicula de terror y acción. Duración: 1h 49', 'Pelicula'),
('Aqui no hay quien viva', '\0Serie de comedia española. 91 episodio', 'Serie'),
('Arcane', '\0Serie animada. 18 episodio', 'Serie'),
('Ark', '\0Juego de supervivencia prehistoric', 'Juego'),
('Baki', '\0Anime de peleas y acción. 4 temporada', 'Anime'),
('Bocadillo de butifarra', '\0pan, butifarr', 'Cocina'),
('Borraja con patatas', '\0borraja, patata', 'Cocina'),
('Cachopo', '\0ternera, queso, jamón, pan rallado, huev', 'Cocina'),
('Chainsawman', '\0Anime de acción. 1 temporad', 'Anime'),
('Croquetas de jamón', '\0Harina, pan rallado, jamón, leche, huevos, sal, cebolla, aceit', 'Cocina'),
('CSGO', '\0Juego de disparos competitiv', 'Juego'),
('Danmachi', '\0Anime de fantasia, magia y aventuras. 5 temporada', 'Anime'),
('Deadpool', '\0Pelicula de acción y comedia. Duración: 1h 48', 'Pelicula'),
('Dr house', '\0Serie de comedia, acción y suspense. 177 episodio', 'Serie'),
('Dr Strange multiverso de la locura', '\0Pelicula de ciencia ficción. Duración: 2h 6', 'Pelicula'),
('Dragon ball', '\0Anime de peleas. 20 temporada', 'Anime'),
('El dictador', '\0Pelicula de comedia y drama. Duración: 1h 23', 'Pelicula'),
('Espaguetis', '\0espaguetis, tomate, ques', 'Cocina'),
('Estofado de carne', '\0verduras, carne, sal, aceite, patata, pimient', 'Cocina'),
('Fortnite', '\0Juego de disparos frenétic', 'Juego'),
('Futurama', '\0Serie de ciencia ficción y comedia. 140 episodio', 'Serie'),
('Genshin impact', '\0Juego mundo abierto de fantasia estilo anim', 'Juego'),
('Gladiator', '\0Pelicula de acción y aventura. Duración: 2h 35', 'Pelicula'),
('God of War', '\0Juego de aventuras hack and slas', 'Juego'),
('Hawai 5.0', '\0Serie de acción. 240 episodio', 'Serie'),
('Honkai star rail', '\0Juego por turnos estilo anim', 'Juego'),
('Jojos', '\0Anime de aventuras. 6 temporada', 'Anime'),
('Kebab', '\0pollo, ternera, cebolla, lechuga, salsa kebab, tomate, ques', 'Cocina'),
('Kimetsu no yaiba', '\0Anime de acción y aventuras. 5 temporada', 'Anime'),
('Konosuba', '\0Anime de magia y aventuras. 3 temporada', 'Anime'),
('La que se avecina', '\0Serie española de comedia. 93 episodio', 'Serie'),
('League of legends', '\0Juego MOBA competitiv', 'Juego'),
('Los simpsons', '\0Serie de comedia. 677 episodio', 'Serie'),
('Los vengadores End Game', '\0Pelicula de superheroes y acción. Duración: 3h 1', 'Pelicula'),
('Menestra de verduras', '\0guisantes, zanahorias, patatas, esparragos, cebolla, setas, judias verdes, jamo', 'Cocina'),
('Minecraft', '\0Juego mundo abierto sandbo', 'Juego'),
('Monster Hunter World', '\0Juego de cazar animales y criatura', 'Juego'),
('My hero academia', '\0Anime de heroes y acción. 8 temporada', 'Anime'),
('Orgullo y prejuicio', '\0Pelicula de romance y comedia. Duración: 2h 7', 'Pelicula'),
('Overlord', '\0Anime de acción y fantasia. 4 temporada', 'Anime'),
('Padre de familia', '\0Comedia. 424 episodio', 'Serie'),
('Paella', '\0Arroz, mariscos, solomillo, verduras varias, mejillones, Sepia, aceite, sal, caldo de paell', 'Cocina'),
('Pokémon', '\0Juego por turnos y de captura de criatura', 'Juego'),
('Shadow hunters', '\0Serie de fantasia y ciencia ficción. 55 episodio', 'Serie'),
('Star Wars El imperio contraataca', '\0Pelicula de ciencia ficción en el espacio. Duración: 2h 4', 'Pelicula'),
('Tarta de queso', '\0queso cremoso, leche, azucar, huevos, galletas, mantequill', 'Cocina'),
('The bing bang theory', '\0Serie de comedia. 279 episodio', 'Serie'),
('The seven deadly sins', '\0Anime de fantasia y aventuras. 5 temporada', 'Anime'),
('Transformers La era de la extinción', '\0Pelicula de ciencia ficción. Duración: 2h 45', 'Pelicula'),
('Venom', '\0Pelicula de acción. Duración: 1h 42', 'Pelicula');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `valoraciones`
--

CREATE TABLE `valoraciones` (
  `ID` int(11) NOT NULL,
  `nombreMultimedia` varchar(50) NOT NULL,
  `nombreUsuario` varchar(50) NOT NULL,
  `valoracion` int(2) NOT NULL,
  `comentario` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cuentas`
--
ALTER TABLE `cuentas`
  ADD PRIMARY KEY (`nombre`);

--
-- Indices de la tabla `multimedia`
--
ALTER TABLE `multimedia`
  ADD PRIMARY KEY (`titulo`);

--
-- Indices de la tabla `valoraciones`
--
ALTER TABLE `valoraciones`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `nombreUsu` (`nombreUsuario`),
  ADD KEY `nombreMulti` (`nombreMultimedia`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `valoraciones`
--
ALTER TABLE `valoraciones`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `valoraciones`
--
ALTER TABLE `valoraciones`
  ADD CONSTRAINT `nombreMulti` FOREIGN KEY (`nombreMultimedia`) REFERENCES `multimedia` (`titulo`),
  ADD CONSTRAINT `nombreUsu` FOREIGN KEY (`nombreUsuario`) REFERENCES `cuentas` (`nombre`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
