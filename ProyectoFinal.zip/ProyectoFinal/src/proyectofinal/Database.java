package proyectofinal;
import com.mysql.cj.jdbc.MysqlDataSource;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;



public class Database {

    static java.sql.Connection connection;

    static MysqlDataSource dataSource;


    public static java.sql.Connection createConnection() throws SQLException {

        dataSource = new MysqlDataSource();
 
        dataSource.setUrl("jdbc:mysql://localhost:3306/proyecto");
        dataSource.setUser("usuario_remoto");
        dataSource.setPassword("c0ntras3na_muy_d1f1c1l_d3_sab3r");

        connection = dataSource.getConnection();
        connection.setAutoCommit(true);

        return connection;

    }

    public static java.sql.Connection getInstance() throws SQLException, IOException {

        if(connection==null) {

            java.sql.Connection conn = createConnection();

            return conn;

        }

        return connection;

    }

    public static void close() throws SQLException {

        if(connection!=null) {

            connection.close();

            connection=null;

        }

    }

    public static int guardarCuenta(String nombre, String contraseña, String nºpregunta, String respuesta) throws SQLException, IOException {
        Connection conn = getInstance();
        if (nombre.isEmpty() || contraseña.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Campos en blanco.");
            return 0;
        }

        PreparedStatement checkStmt = conn.prepareStatement("SELECT nombre FROM cuentas WHERE nombre = ?");
        checkStmt.setString(1, nombre);
        ResultSet rs = checkStmt.executeQuery();

        if (rs.next()) {
            JOptionPane.showMessageDialog(null, "Error al guardar. Nombre de usuario ya registrado.");
            return 0;
        }
        
        PreparedStatement insertStmt = conn.prepareStatement("INSERT INTO cuentas (nombre, contraseña, pregunta, respuesta) VALUES (?, ?, ?, ?)");
        insertStmt.setString(1, nombre);
        insertStmt.setString(2, contraseña);
        insertStmt.setString(3, nºpregunta);
        insertStmt.setString(4, respuesta);

        int affectedRows = insertStmt.executeUpdate();
    
        if (affectedRows > 0) {
            JOptionPane.showMessageDialog(null, "Cuenta registrada con éxito.");
            return 1;
        } else {
            JOptionPane.showMessageDialog(null, "Error al registrar la cuenta.");
            return 0;
        }
    }
    
    public static int modificarCuenta(String nombre, String contraseña, String pregunta, String respuesta, String nombreActual) throws SQLException, IOException{
        Connection conn = getInstance();
        try {
            PreparedStatement disableFKChecks = conn.prepareStatement("SET FOREIGN_KEY_CHECKS = 0");
            disableFKChecks.execute();

            if (nombre.isEmpty()) {
                nombre = nombreActual;
            } else {
                PreparedStatement stmt = conn.prepareStatement("SELECT COUNT(*) FROM cuentas WHERE nombre = ? AND nombre <> ?");
                stmt.setString(1, nombre);
                stmt.setString(2, nombreActual);
                ResultSet rs = stmt.executeQuery();

                if (rs.next() && rs.getInt(1) > 0) {
                    JOptionPane.showMessageDialog(null, "Error al modificar. Nombre de usuario ya registrado.");
                    return 0;
                }
            }

            if (contrase\u00f1a.isEmpty()) {
                PreparedStatement stmt = conn.prepareStatement("SELECT contrase\u00f1a FROM cuentas WHERE nombre = ?");
                stmt.setString(1, nombreActual);
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    contrase\u00f1a = rs.getString(1);
                }
            }
            if (respuesta.isEmpty()) {
                PreparedStatement stmt = conn.prepareStatement("SELECT respuesta FROM cuentas WHERE nombre = ?");
                stmt.setString(1, nombreActual);
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    respuesta = rs.getString(1);
                }
            }

            PreparedStatement stmtValoraciones = conn.prepareStatement("UPDATE valoraciones SET nombreUsuario = ? WHERE nombreUsuario = ?");
            stmtValoraciones.setString(1, nombre);
            stmtValoraciones.setString(2, nombreActual);
            stmtValoraciones.executeUpdate();

            PreparedStatement stmtCuentas = conn.prepareStatement("UPDATE cuentas SET nombre = ?, contrase\u00f1a = ?, pregunta = ?, respuesta = ? WHERE nombre = ?");
            stmtCuentas.setString(1, nombre);
            stmtCuentas.setString(2, contrase\u00f1a);
            stmtCuentas.setString(3, pregunta);
            stmtCuentas.setString(4, respuesta);
            stmtCuentas.setString(5, nombreActual);

            int affectedRows = stmtCuentas.executeUpdate();

            PreparedStatement enableFKChecks = conn.prepareStatement("SET FOREIGN_KEY_CHECKS = 1");
            enableFKChecks.execute();

            if (affectedRows > 0) {
                JOptionPane.showMessageDialog(null, "Datos modificados con éxito.");
                return 1;
            } else {
                JOptionPane.showMessageDialog(null, "Error al modificar los datos.");
                return 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
    }


    public static int iniciarSesion(String nombre, String contraseña) throws SQLException, IOException {
        Connection conn = getInstance();
        String nombreCorrecto = null;
        String contraseñaCorrecto = null;
        if(nombre.isEmpty() || contraseña.isEmpty()){
            return 0;
        }
        else{
            PreparedStatement stmt = conn.prepareStatement("SELECT nombre, contraseña FROM cuentas");
            ResultSet rs = stmt.executeQuery();

            while(rs.next()){
                nombreCorrecto = rs.getString(1);
                contraseñaCorrecto = rs.getString(2);
                
                if(nombre.equals(nombreCorrecto) && contraseña.equals(contraseñaCorrecto)){
                return 1;
                }
            }
        }
        return 2;
    }
    
    public static int consultarCuenta(String respuesta, String usuario) throws SQLException, IOException {
        Connection conn = getInstance();
        String contraseña = null;
        String respuestaCorrecta = null;
        if(usuario.isEmpty() && respuesta.isEmpty()){
            JOptionPane.showMessageDialog(null, "Campos en blanco.");
            return 3;
        }
        else if(usuario.isEmpty()){
            JOptionPane.showMessageDialog(null, "Campo en blanco. Introduzca su usuario.");
            return 4;
        }
        else if(respuesta.isEmpty()){
            JOptionPane.showMessageDialog(null, "Campo en blanco. Introduzca su respuesta.");
            return 5;
        }
        else{
            PreparedStatement stmt = conn.prepareStatement("SELECT contraseña, respuesta FROM cuentas");
            ResultSet rs = stmt.executeQuery();

            while(rs.next()){
                contraseña = rs.getString(1);
                respuestaCorrecta = rs.getString(2);
                
                if(respuesta.equals(respuestaCorrecta)){
                    JOptionPane.showMessageDialog(null, "Contraseña de la cuenta es: " + contraseña);
                    return 1;
                }
            }
        }
        return 2;
    }
    
    public static String preguntaSeguridad(String usuario) throws SQLException, IOException {
        Connection conn = getInstance();
        PreparedStatement stmt = conn.prepareStatement("SELECT pregunta FROM cuentas WHERE nombre = ?");
        stmt.setString(1, usuario);
        ResultSet rs = stmt.executeQuery();

        if(rs.next()){
            return rs.getString("pregunta");
        }
        return null;
    }
    public static String respuestaSeguridad(String usuario) throws SQLException, IOException {
        Connection conn = getInstance();
        PreparedStatement stmt = conn.prepareStatement("SELECT respuesta FROM cuentas WHERE nombre = ?");
        stmt.setString(1, usuario);
        ResultSet rs = stmt.executeQuery();

        if(rs.next()){
            return rs.getString("respuesta");
        }
        return null;
    }
    
    public static String contraseña(String usuario) throws SQLException, IOException {
        Connection conn = getInstance();
        PreparedStatement stmt = conn.prepareStatement("SELECT contraseña FROM cuentas WHERE nombre = ?");
        stmt.setString(1, usuario);
        ResultSet rs = stmt.executeQuery();

        if(rs.next()){
            return rs.getString("contraseña");
        }
        return null;
    }
    
    public static int agregarFilaBD(String titulo, String descripcion, String genero) throws SQLException, IOException {
        Connection conn = getInstance();
        String checkSql = "SELECT COUNT(*) FROM multimedia WHERE titulo = ?";
        try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
            checkStmt.setString(1, titulo);
            ResultSet rs = checkStmt.executeQuery();
            if (rs.next()) {
                int count = rs.getInt(1);
                if (count > 0) {
                    return -1;
                }
            }
        }
        String sql = "INSERT INTO multimedia (titulo, descripcion, genero) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, titulo);
            stmt.setString(2, descripcion);
            stmt.setString(3, genero);
            return stmt.executeUpdate();
        }
    }

    public static int eliminarFilaBD(String titulo) throws SQLException, IOException {
    Connection conn = getInstance();
    String sqlEliminarValoraciones = "DELETE FROM valoraciones WHERE nombreMultimedia = ?";
    String sqlEliminarMultimedia = "DELETE FROM multimedia WHERE titulo = ?";

    try (PreparedStatement stmtValoraciones = conn.prepareStatement(sqlEliminarValoraciones);
         PreparedStatement stmtMultimedia = conn.prepareStatement(sqlEliminarMultimedia)) {
        stmtValoraciones.setString(1, titulo);
        stmtValoraciones.executeUpdate();
        stmtMultimedia.setString(1, titulo);
        return stmtMultimedia.executeUpdate();
    }
}

    public static List<String[]> cargarDatos() throws SQLException, IOException {
        List<String[]> datos = new ArrayList<>();
        Connection conn = getInstance();
        String sql = "SELECT titulo, descripcion, genero FROM multimedia";
        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                String[] fila = new String[3];
                fila[0] = rs.getString("titulo");
                fila[1] = rs.getString("descripcion");
                fila[2] = rs.getString("genero");
                datos.add(fila);
            }
        }
        return datos;
    }
    
    public static List<String[]> cargarDatosP() throws SQLException, IOException {
        List<String[]> datos = new ArrayList<>();
        Connection conn = getInstance();

        String sql = "SELECT multimedia.titulo, multimedia.descripcion, " +
                     "COALESCE(AVG(valoraciones.valoracion), 0) AS valoracionPromedio " +
                     "FROM multimedia " +
                     "LEFT JOIN valoraciones ON multimedia.titulo = valoraciones.nombreMultimedia " +
                     "WHERE multimedia.genero = 'Pelicula' " +
                     "GROUP BY multimedia.titulo, multimedia.descripcion";
        
        DecimalFormat formatoDecimal = new DecimalFormat("0.0");
        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                String[] fila = new String[3];
                fila[0] = rs.getString("titulo");
                fila[1] = rs.getString("descripcion");
                double valoracionPromedio = rs.getDouble("valoracionPromedio");
                fila[2] = formatoDecimal.format(valoracionPromedio);
                datos.add(fila);
            }
        }
        return datos;
    }
    
    public static List<String[]> cargarDatosPComentarios() throws SQLException, IOException {
        List<String[]> datos = new ArrayList<>();
        Connection conn = getInstance();
        String sql = "SELECT nombreUsuario, nombreMultimedia, Comentario FROM valoraciones LEFT JOIN multimedia ON valoraciones.nombreMultimedia = multimedia.titulo WHERE multimedia.genero = 'Pelicula'";
        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                String[] fila = new String[3];
                fila[0] = rs.getString("nombreUsuario");
                fila[1] = rs.getString("nombreMultimedia");
                fila[2] = rs.getString("Comentario");
                datos.add(fila);
            }
        }
        return datos;
    }
    
    public static int añadirValoraciones(String titulo, String usuario, int valoracion, String comentario) throws SQLException, IOException {
        Connection conn = getInstance();
        String consultaValoracion = "SELECT COUNT(*) FROM valoraciones WHERE nombreMultimedia = ? AND nombreUsuario = ?";
        boolean yaValorado = false;

        try (PreparedStatement stmtConsulta = conn.prepareStatement(consultaValoracion)) {
            stmtConsulta.setString(1, titulo);
            stmtConsulta.setString(2, usuario);
            try (ResultSet rs = stmtConsulta.executeQuery()) {
                if (rs.next() && rs.getInt(1) > 0) {
                    yaValorado = true;
                }
            }
        }
        String sql;
        if (yaValorado) {
            sql = "UPDATE valoraciones SET valoracion = ?, comentario = ? WHERE nombreMultimedia = ? AND nombreUsuario = ?";
        } else {
            sql = "INSERT INTO valoraciones (nombreMultimedia, nombreUsuario, valoracion, comentario) VALUES (?, ?, ?, ?)";
        }
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, titulo);
            stmt.setString(2, usuario);
            stmt.setInt(3, valoracion);
            stmt.setString(4, comentario);
            return stmt.executeUpdate();
        }
    }
    
    public static List<String[]> cargarDatosS() throws SQLException, IOException {
        List<String[]> datos = new ArrayList<>();
        Connection conn = getInstance();

        String sql = "SELECT multimedia.titulo, multimedia.descripcion, " +
                     "COALESCE(AVG(valoraciones.valoracion), 0) AS valoracionPromedio " +
                     "FROM multimedia " +
                     "LEFT JOIN valoraciones ON multimedia.titulo = valoraciones.nombreMultimedia " +
                     "WHERE multimedia.genero = 'Serie' " +
                     "GROUP BY multimedia.titulo, multimedia.descripcion";
        
        DecimalFormat formatoDecimal = new DecimalFormat("0.0");
        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                String[] fila = new String[3];
                fila[0] = rs.getString("titulo");
                fila[1] = rs.getString("descripcion");
                double valoracionPromedio = rs.getDouble("valoracionPromedio");
                fila[2] = formatoDecimal.format(valoracionPromedio);
                datos.add(fila);
            }
        }
        return datos;
    }
    
    public static List<String[]> cargarDatosSComentarios() throws SQLException, IOException {
        List<String[]> datos = new ArrayList<>();
        Connection conn = getInstance();
        String sql = "SELECT nombreUsuario, nombreMultimedia, Comentario FROM valoraciones LEFT JOIN multimedia ON valoraciones.nombreMultimedia = multimedia.titulo WHERE multimedia.genero = 'Serie'";
        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                String[] fila = new String[3];
                fila[0] = rs.getString("nombreUsuario");
                fila[1] = rs.getString("nombreMultimedia");
                fila[2] = rs.getString("Comentario");
                datos.add(fila);
            }
        }
        return datos;
    }
    
    public static List<String[]> cargarDatosA() throws SQLException, IOException {
        List<String[]> datos = new ArrayList<>();
        Connection conn = getInstance();

        String sql = "SELECT multimedia.titulo, multimedia.descripcion, " +
                     "COALESCE(AVG(valoraciones.valoracion), 0) AS valoracionPromedio " +
                     "FROM multimedia " +
                     "LEFT JOIN valoraciones ON multimedia.titulo = valoraciones.nombreMultimedia " +
                     "WHERE multimedia.genero = 'Anime' " +
                     "GROUP BY multimedia.titulo, multimedia.descripcion";
        
        DecimalFormat formatoDecimal = new DecimalFormat("0.0");
        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                String[] fila = new String[3];
                fila[0] = rs.getString("titulo");
                fila[1] = rs.getString("descripcion");
                double valoracionPromedio = rs.getDouble("valoracionPromedio");
                fila[2] = formatoDecimal.format(valoracionPromedio);
                datos.add(fila);
            }
        }
        return datos;
    }
    
    public static List<String[]> cargarDatosAComentarios() throws SQLException, IOException {
        List<String[]> datos = new ArrayList<>();
        Connection conn = getInstance();
        String sql = "SELECT nombreUsuario, nombreMultimedia, Comentario FROM valoraciones LEFT JOIN multimedia ON valoraciones.nombreMultimedia = multimedia.titulo WHERE multimedia.genero = 'Anime'";
        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                String[] fila = new String[3];
                fila[0] = rs.getString("nombreUsuario");
                fila[1] = rs.getString("nombreMultimedia");
                fila[2] = rs.getString("Comentario");
                datos.add(fila);
            }
        }
        return datos;
    }
    
    public static List<String[]> cargarDatosJ() throws SQLException, IOException {
        List<String[]> datos = new ArrayList<>();
        Connection conn = getInstance();

        String sql = "SELECT multimedia.titulo, multimedia.descripcion, " +
                     "COALESCE(AVG(valoraciones.valoracion), 0) AS valoracionPromedio " +
                     "FROM multimedia " +
                     "LEFT JOIN valoraciones ON multimedia.titulo = valoraciones.nombreMultimedia " +
                     "WHERE multimedia.genero = 'Juego' " +
                     "GROUP BY multimedia.titulo, multimedia.descripcion";
        
        DecimalFormat formatoDecimal = new DecimalFormat("0.0");
        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                String[] fila = new String[3];
                fila[0] = rs.getString("titulo");
                fila[1] = rs.getString("descripcion");
                double valoracionPromedio = rs.getDouble("valoracionPromedio");
                fila[2] = formatoDecimal.format(valoracionPromedio);
                datos.add(fila);
            }
        }
        return datos;
    }
    
    public static List<String[]> cargarDatosJComentarios() throws SQLException, IOException {
        List<String[]> datos = new ArrayList<>();
        Connection conn = getInstance();
        String sql = "SELECT nombreUsuario, nombreMultimedia, Comentario FROM valoraciones LEFT JOIN multimedia ON valoraciones.nombreMultimedia = multimedia.titulo WHERE multimedia.genero = 'Juego'";
        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                String[] fila = new String[3];
                fila[0] = rs.getString("nombreUsuario");
                fila[1] = rs.getString("nombreMultimedia");
                fila[2] = rs.getString("Comentario");
                datos.add(fila);
            }
        }
        return datos;
    }
    
    public static List<String[]> cargarDatosC() throws SQLException, IOException {
        List<String[]> datos = new ArrayList<>();
        Connection conn = getInstance();

        String sql = "SELECT multimedia.titulo, multimedia.descripcion, " +
                     "COALESCE(AVG(valoraciones.valoracion), 0) AS valoracionPromedio " +
                     "FROM multimedia " +
                     "LEFT JOIN valoraciones ON multimedia.titulo = valoraciones.nombreMultimedia " +
                     "WHERE multimedia.genero = 'Cocina' " +
                     "GROUP BY multimedia.titulo, multimedia.descripcion";
        
        DecimalFormat formatoDecimal = new DecimalFormat("0.0");
        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                String[] fila = new String[3];
                fila[0] = rs.getString("titulo");
                fila[1] = rs.getString("descripcion");
                double valoracionPromedio = rs.getDouble("valoracionPromedio");
                fila[2] = formatoDecimal.format(valoracionPromedio);
                datos.add(fila);
            }
        }
        return datos;
    }
    
    public static List<String[]> cargarDatosCComentarios() throws SQLException, IOException {
        List<String[]> datos = new ArrayList<>();
        Connection conn = getInstance();
        String sql = "SELECT nombreUsuario, nombreMultimedia, Comentario FROM valoraciones LEFT JOIN multimedia ON valoraciones.nombreMultimedia = multimedia.titulo WHERE multimedia.genero = 'Cocina'";
        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                String[] fila = new String[3];
                fila[0] = rs.getString("nombreUsuario");
                fila[1] = rs.getString("nombreMultimedia");
                fila[2] = rs.getString("Comentario");
                datos.add(fila);
            }
        }
        return datos;
    }
}
