/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectofinal;

import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author Pedro José Gascón
 */
public class JPaneLImage extends JLabel {
    private Image img;

    public JPaneLImage(JPanel panel, String path) {
        this.img = new ImageIcon(getClass().getResource(path)).getImage();
        this.setOpaque(true);
        this.setSize(panel.getSize());
        this.setPreferredSize(panel.getSize());
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (img != null) {
            g.drawImage(img, 0, 0, getWidth(), getHeight(), this);
        }
    }
}
